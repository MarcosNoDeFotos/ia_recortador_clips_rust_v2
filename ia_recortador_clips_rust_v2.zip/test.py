import os

video_path = "//192.168.1.188/videos3/2025-11-28 17-29.mp4"
print(os.path.basename(video_path))